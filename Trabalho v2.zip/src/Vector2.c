#include "../include/Vector2.h"

bool Vector2_equals(Vector2 a, Vector2 b) { return a.x == b.x && a.y == b.y; }
