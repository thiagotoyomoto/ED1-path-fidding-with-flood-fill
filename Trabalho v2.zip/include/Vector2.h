#ifndef VECTOR2_H
#define VECTOR2_H

#include <stdbool.h>

typedef struct Vector2 Vector2;

struct Vector2 {
  int x;
  int y;
};

bool Vector2_equals(Vector2, Vector2);

#endif /* VECTOR2_H */
